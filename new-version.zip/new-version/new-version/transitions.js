// Get all the elements that should have animations
const elements = document.querySelectorAll('.right-left, .left-right, .top-bottom, .bottom-top, .fade-in, .fade-out, .bounce-in, .bounce-out');
// Function to check if an element is in the viewport
function isElementInViewport(el) {
  const rect = el.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}
// Function to add the "visible" class if the element is in the viewport
function animateElementsOnScroll() {
  const isMobileDevice = window.innerWidth <= 768; // Adjust the breakpoint as needed
  elements.forEach((element) => {
    if (!isMobileDevice) {
      if (isElementInViewport(element) && !element.classList.contains('visible')) {
        element.classList.add('visible');
      }
    } else {
      element.classList.add('visible');
    }
  });
}
// Add event listener to trigger animations on scroll
window.addEventListener('scroll', animateElementsOnScroll);

// Trigger the animations on initial page load
animateElementsOnScroll();
